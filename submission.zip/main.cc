#include "gameController.h"
#include <iostream>

int main(int argc, char const *argv[]) {

    gameController game = gameController();
    game.run();
    return 0;

}

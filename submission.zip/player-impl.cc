#include "player.h"


Player::Player(int playerNum, int level, string filename): playerNum{playerNum}, grid {make_unique<Grid>()} {
    // text = make_shared<TextObserver>(0, 18, 0, 11, grid);
    this->level = level;
    this->filename = filename;
    updateLevel();
    grid->setCurrent(playerLevel->generateBlock());
    if (playerNum == 1) {
        this->nextBlock = playerLevel->generateBlock();
    }
    this->hiscore = 0;
    this->blind = false;
    this->heavy = false;
    this->force = false;
}

void Player::incrementLevel() {
    if (level < maxlevel) {
        level++;
    }
    updateLevel();
}

void Player::decrementLevel() {
    if (level > minlevel) {
        level--;
    }
    this->updateLevel();
}

void Player::updateLevel() {
    if (level == 0) {
        playerLevel.reset(); // should be reset, not release
        playerLevel = make_unique<Level0>(filename, grid.get());
    } else if (level == 1) {
        playerLevel.reset();
        playerLevel = make_unique<Level1>(grid.get());
    } else if (level == 2) {
        playerLevel.reset();
        playerLevel = make_unique<Level2>(grid.get());
    } else if (level == 3) {
        playerLevel.reset();
        playerLevel = make_unique<Level3>(grid.get());
    } else if (level == 4) {
        playerLevel.reset();
        playerLevel = make_unique<Level4>(grid.get());
    }
    grid->setLevel(level); // sets the grid's level accordingly
}
int Player::returnLevel(){
    return level;
}

